Repro bundle for run: 20260408_011039_px4_sih
Created at: 2026-04-08T22:24:22+08:00

Contains:
- results_20260408_011039_px4_sih/ (full run dir)
- px4_rootfs/1/parameters.bson + px4_rootfs/2/parameters.bson
- px4_airframes/10040_sihsim_quadx + 10041_sihsim_airplane
- git_snapshot_easydocking.txt (+ git_snapshot_px4.txt)
- ros_px4_msgs_snapshot.txt
- ros_topic_list_vehicle_status.txt (live best-effort)
- vehicle_status_from_logs.txt (grep from run logs)
- env_export_time.txt + env_from_metadata.txt
- start_command_repro.txt
